#!/usr/bin/env node
import { Command } from "commander";
import { registerAds } from "./commands/ads.js";
import { registerAuditTrace } from "./commands/audit-trace.js";
import { registerAuth } from "./commands/auth.js";
import { registerBrand } from "./commands/brand.js";
import { registerBrief } from "./commands/brief.js";
import { registerCatalog } from "./commands/catalog.js";
import { registerDesign } from "./commands/design.js";
import { registerInit } from "./commands/init.js";
import { registerLogin } from "./commands/login.js";
import { registerLogo } from "./commands/logo.js";
import { registerResolve } from "./commands/resolve.js";
import { registerSocial } from "./commands/social.js";
import { registerUsage } from "./commands/usage.js";
import { bindOutputProgram } from "./output.js";

const program = new Command();
program
  .name("brandwork")
  .description("Ad and brand intelligence substrate for agents")
  .version("0.0.0")
  .option("--json", "Emit machine-readable JSON output instead of human text")
  .option("--quiet", "Suppress non-error output");

bindOutputProgram(program);

registerInit(program);
registerLogin(program);
registerAuth(program);
registerAuditTrace(program);
registerAds(program);
registerBrand(program);
registerBrief(program);
registerCatalog(program);
registerDesign(program);
registerLogo(program);
registerResolve(program);
registerSocial(program);
registerUsage(program);

program.parseAsync(process.argv);
