import { randomUUID } from "node:crypto";
import { resolve } from "node:path";
import type { AdSource } from "@brandwork/sdk";
import Database from "better-sqlite3";
import type { Command } from "commander";
import { clientFromEnv } from "../client.js";
import { emit, progress, runAction } from "../output.js";
import { withSyncRun } from "../sync-runs.js";

type SourceFlag = AdSource | "all" | "exa";

const ALLOWED_SOURCES: ReadonlyArray<SourceFlag> = [
  "meta",
  "tiktok",
  "google",
  "manual",
  "all",
  "exa",
];

function parseSource(v: string): SourceFlag {
  if ((ALLOWED_SOURCES as readonly string[]).includes(v)) {
    return v as SourceFlag;
  }
  throw new Error(`--source must be one of ${ALLOWED_SOURCES.join("|")} (got: ${v})`);
}

interface NormalisedAd {
  source: "meta" | "tiktok" | "google" | "manual";
  external_id: string;
  url: string | null;
  body: string | null;
  cta: string | null;
  first_seen_at: number;
  last_seen_at: number;
  raw_json: unknown;
}

const insertAdsSql = `
  INSERT INTO ads (
    id, brand_id, source, external_id, url, body, cta,
    first_seen_at, last_seen_at, raw_json
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(source, external_id) DO UPDATE SET
    url = excluded.url,
    body = excluded.body,
    cta = excluded.cta,
    last_seen_at = excluded.last_seen_at,
    raw_json = excluded.raw_json
`;

function upsertAds(db: Database.Database, ads: NormalisedAd[], brandId: string | null): void {
  const insert = db.prepare(insertAdsSql);
  const insertMany = db.transaction((rows: NormalisedAd[]) => {
    for (const ad of rows) {
      insert.run(
        randomUUID(),
        brandId,
        ad.source,
        ad.external_id,
        ad.url,
        ad.body,
        ad.cta,
        ad.first_seen_at,
        ad.last_seen_at,
        JSON.stringify(ad.raw_json),
      );
    }
  });
  insertMany(ads);
}

export function registerAds(program: Command) {
  const ads = program.command("ads").description("Sync and query ad creatives");

  ads
    .command("sync")
    .description("Pull ads from a connected library into the local SQLite")
    .option("--source <source>", "meta (only source implemented today)", "meta")
    .option("--ad-account-id <id>", "Specific Meta ad account (e.g. act_1234…). Omit to sync all")
    .option("--limit <n>", "Max ads per ad account", "50")
    .option("--db <path>", "SQLite path", ".brandwork/brandwork.sqlite")
    .option("--brand-id <uuid>", "Brand id to tag the ads with (FK into brands)")
    .option("--base-url <url>", "Override API base URL")
    .action(
      (opts: {
        source: string;
        adAccountId?: string;
        limit: string;
        db: string;
        brandId?: string;
        baseUrl?: string;
      }) =>
        runAction(async () => {
          const source = parseSource(opts.source);
          if (source !== "meta") {
            throw new Error("only --source=meta is implemented today");
          }
          const client = await clientFromEnv(opts.baseUrl);

          const accounts = opts.adAccountId
            ? [{ id: opts.adAccountId, account_id: opts.adAccountId.replace(/^act_/, "") }]
            : (await client.ads.meta.accounts()).accounts;

          if (accounts.length === 0) {
            throw new Error(
              "No Meta ad accounts. Run `brandwork auth meta` to connect a Meta account first.",
            );
          }

          const dbPath = resolve(process.cwd(), opts.db);
          const db = new Database(dbPath);
          db.pragma("foreign_keys = ON");

          const limit = Math.min(Math.max(Number.parseInt(opts.limit, 10) || 50, 1), 500);
          let totalAds = 0;
          try {
            await withSyncRun(db, { kind: "ads", source: "meta" }, async () => {
              for (const acct of accounts) {
                progress(`fetching ads for ${acct.id}${acct.name ? ` (${acct.name})` : ""}…`);
                const result = await client.ads.meta.fetch(acct.id, limit);
                upsertAds(db, result.ads, opts.brandId ?? null);
                totalAds += result.ads.length;
                progress(`  ${result.ads.length} ads from ${acct.id}`);
              }
            });
          } finally {
            db.close();
          }

          emit(
            { source: "meta", accounts: accounts.length, ads: totalAds, db: dbPath },
            `synced ${totalAds} ads from ${accounts.length} Meta ad account(s) → ${dbPath}`,
          );
        }),
    );

  ads
    .command("search <query>")
    .description("Search public ads via Exa + Scrapecreators; writes into local ads table")
    .option("--source <source>", "exa|meta|tiktok|google|all", "all")
    .option("--brand <domain>", "Brand to scope ad-library searches")
    .option("--limit <n>", "Max results", "20")
    .option("--db <path>", "SQLite path", ".brandwork/brandwork.sqlite")
    .option("--no-save", "Skip writing rows to the local SQLite")
    .option("--base-url <url>", "Override API base URL")
    .action(
      (
        query: string,
        opts: {
          source: string;
          brand?: string;
          limit: string;
          db: string;
          save: boolean;
          baseUrl?: string;
        },
      ) =>
        runAction(async () => {
          const source = parseSource(opts.source);
          const client = await clientFromEnv(opts.baseUrl);
          const result = await client.ads.search({
            query,
            source,
            limit: Number.parseInt(opts.limit, 10),
            brand: opts.brand,
          });

          if (opts.save !== false) {
            const dbPath = resolve(process.cwd(), opts.db);
            const db = new Database(dbPath);
            db.pragma("foreign_keys = ON");
            try {
              await withSyncRun(db, { kind: "ads", source }, async () => {
                upsertAds(db, result.ads, null);
              });
            } finally {
              db.close();
            }
            emit(result, `${result.count} ads (saved to ${dbPath})`);
          } else {
            emit(result, JSON.stringify(result, null, 2));
          }
        }),
    );
}
