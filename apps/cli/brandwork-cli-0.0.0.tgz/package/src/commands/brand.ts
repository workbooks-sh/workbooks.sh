import { resolve } from "node:path";
import Database from "better-sqlite3";
import type { Command } from "commander";
import { clientFromEnv } from "../client.js";
import { emit, runAction, say } from "../output.js";
import { withSyncRun } from "../sync-runs.js";
import { extractBrandFonts } from "./brand-fonts.js";

export function registerBrand(program: Command) {
  const brand = program.command("brand").description("Fetch brand identity");

  brand
    .command("fetch <domain>")
    .description("Fetch logo, palette, descriptors for a brand; writes to local SQLite")
    .option("--db <path>", "SQLite path", ".brandwork/brandwork.sqlite")
    .option("--no-save", "Skip writing to local SQLite")
    .option("--base-url <url>", "Override API base URL")
    .action((domain: string, opts: { db: string; save: boolean; baseUrl?: string }) =>
      runAction(async () => {
        const client = await clientFromEnv(opts.baseUrl);
        const result = await client.brand.fetch(domain);
        const b = result.brand;

        if (opts.save !== false) {
          const dbPath = resolve(process.cwd(), opts.db);
          const db = new Database(dbPath);
          db.pragma("foreign_keys = ON");
          try {
            // sync_runs.brand_id is FK-enforced; we omit it here because the
            // brands row doesn't exist yet at this point.
            await withSyncRun(db, { kind: "brand", source: "context-dev" }, async () => {
              db.prepare(
                `INSERT INTO brands (
                   id, domain, name, logo_url, palette_json, descriptors_json, fetched_at
                 ) VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON CONFLICT(domain) DO UPDATE SET
                   name = excluded.name,
                   logo_url = excluded.logo_url,
                   palette_json = excluded.palette_json,
                   descriptors_json = excluded.descriptors_json,
                   fetched_at = excluded.fetched_at`,
              ).run(
                b.id,
                b.domain,
                b.name,
                b.logo_url,
                b.palette_json,
                b.descriptors_json,
                b.fetched_at,
              );
            });
          } finally {
            db.close();
          }
          emit(result, `${domain}: ${b.name ?? "(no title)"} saved to ${dbPath}`);
        } else {
          emit(result, JSON.stringify(result, null, 2));
        }
      }),
    );

  brand
    .command("fonts <domain>")
    .description(
      "Extract web fonts from a brand's homepage — @font-face, Google Fonts, Adobe Typekit. Falls back to the managed API on WAF-blocked sites.",
    )
    .option("--base-url <url>", "Override API base URL (used for WAF-bypass fallback)")
    .action((domain: string, opts: { baseUrl?: string }) =>
      runAction(async () => {
        say(`Extracting fonts for ${domain}…`);
        const result = await extractBrandFonts(domain, { baseUrl: opts.baseUrl });
        const summary = formatFontResultForHuman(result);
        emit(result, summary);
      }),
    );
}

function formatFontResultForHuman(result: {
  domain: string;
  primary_font: {
    family: string;
    weights: number[];
    italic_supported: boolean;
    source: string;
    files?: string[];
  } | null;
  secondary_font: {
    family: string;
    weights: number[];
    italic_supported: boolean;
    source: string;
  } | null;
  stack_css: string | null;
  headings_stack_css: string | null;
  body_stack_css: string | null;
  found_at: string[];
  error?: string;
}): string {
  if (result.error) {
    return `fonts: ${result.domain} — ${result.error}`;
  }
  const lines: string[] = [`fonts: ${result.domain}`];
  if (result.primary_font) {
    const pf = result.primary_font;
    lines.push(
      `  primary: ${pf.family}  [${pf.weights.join(", ")}]${pf.italic_supported ? " italic" : ""}`,
    );
    lines.push(`    source: ${pf.source}`);
    if (pf.files && pf.files.length > 0) {
      lines.push(`    files: ${pf.files.slice(0, 3).join(", ")}${pf.files.length > 3 ? " …" : ""}`);
    }
  }
  if (result.secondary_font) {
    const sf = result.secondary_font;
    lines.push(`  secondary: ${sf.family}  [${sf.weights.join(", ")}]`);
  }
  if (result.stack_css) lines.push(`  stack: ${result.stack_css}`);
  if (result.headings_stack_css) lines.push(`  headings: ${result.headings_stack_css}`);
  if (result.body_stack_css) lines.push(`  body: ${result.body_stack_css}`);
  if (result.found_at.length > 0) {
    lines.push(`  found in ${result.found_at.length} stylesheet(s)`);
  }
  return lines.join("\n");
}
