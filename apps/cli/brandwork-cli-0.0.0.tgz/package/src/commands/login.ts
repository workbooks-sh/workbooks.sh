// `brandwork login` — GitHub device-flow sign-in.
//
// The CLI talks to the worker's /auth/cli/config to learn the GitHub
// OAuth client_id, runs the device flow against github.com directly,
// then POSTs the resulting GitHub access_token to /auth/cli/exchange
// for an brandwork API key. The key is stored in the OS keychain.

import type { Command } from "commander";
import { baseUrlFromEnv } from "../client.js";
import { setApiKey } from "../keychain.js";

interface CliConfig {
  github_client_id: string;
  device_endpoint: string;
  token_endpoint: string;
  scopes: string;
}

interface DeviceCodeResponse {
  device_code: string;
  user_code: string;
  verification_uri: string;
  expires_in: number;
  interval: number;
}

interface DevicePollPending {
  error: "authorization_pending" | "slow_down";
  interval?: number;
}

interface DevicePollSuccess {
  access_token: string;
  token_type: string;
  scope?: string;
}

interface DevicePollError {
  error: string;
  error_description?: string;
}

type DevicePollResponse = DevicePollSuccess | DevicePollPending | DevicePollError;

interface ExchangeResponse {
  api_key: string;
  prefix: string;
  user: { id: string; github_login: string; email: string | null };
}

async function fetchConfig(baseUrl: string): Promise<CliConfig> {
  const res = await fetch(`${baseUrl}/auth/cli/config`);
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`auth/cli/config returned ${res.status}: ${body}`);
  }
  return (await res.json()) as CliConfig;
}

async function startDeviceFlow(config: CliConfig): Promise<DeviceCodeResponse> {
  const params = new URLSearchParams({
    client_id: config.github_client_id,
    scope: config.scopes,
  });
  const res = await fetch(config.device_endpoint, {
    method: "POST",
    headers: { accept: "application/json", "content-type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  if (!res.ok) {
    throw new Error(`GitHub device flow init failed: ${res.status}`);
  }
  return (await res.json()) as DeviceCodeResponse;
}

async function pollOnce(config: CliConfig, deviceCode: string): Promise<DevicePollResponse> {
  const params = new URLSearchParams({
    client_id: config.github_client_id,
    device_code: deviceCode,
    grant_type: "urn:ietf:params:oauth:grant-type:device_code",
  });
  const res = await fetch(config.token_endpoint, {
    method: "POST",
    headers: { accept: "application/json", "content-type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  return (await res.json()) as DevicePollResponse;
}

async function pollForToken(config: CliConfig, device: DeviceCodeResponse): Promise<string> {
  const deadline = Date.now() + device.expires_in * 1000;
  let interval = Math.max(device.interval, 5);

  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, interval * 1000));
    const res = await pollOnce(config, device.device_code);
    if ("access_token" in res) {
      return res.access_token;
    }
    if ("error" in res) {
      if (res.error === "authorization_pending") continue;
      if (res.error === "slow_down") {
        interval = Math.min(interval + 5, 30);
        continue;
      }
      const desc = "error_description" in res ? res.error_description : undefined;
      throw new Error(`device-flow ${res.error}: ${desc ?? ""}`);
    }
  }
  throw new Error("device-flow timed out — please run `brandwork login` again");
}

async function exchange(
  baseUrl: string,
  githubToken: string,
  label: string,
): Promise<ExchangeResponse> {
  const res = await fetch(`${baseUrl}/auth/cli/exchange`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ github_token: githubToken, label }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`auth/cli/exchange returned ${res.status}: ${body}`);
  }
  return (await res.json()) as ExchangeResponse;
}

export function registerLogin(program: Command) {
  program
    .command("login")
    .description("Sign in to Brandwork via GitHub device flow; stores API key in OS keychain")
    .option("--base-url <url>", "Override API base URL")
    .option("--label <label>", "Label for the minted API key", `cli@${process.env.USER ?? "local"}`)
    .action(async (opts: { baseUrl?: string; label: string }) => {
      const baseUrl = baseUrlFromEnv(opts.baseUrl);
      const config = await fetchConfig(baseUrl);
      const device = await startDeviceFlow(config);

      process.stdout.write(
        [
          "",
          `Open: ${device.verification_uri}`,
          `Enter code: ${device.user_code}`,
          "",
          "Waiting for you to authorize on GitHub…",
          "",
        ].join("\n"),
      );

      const githubToken = await pollForToken(config, device);
      const result = await exchange(baseUrl, githubToken, opts.label);
      const stored = await setApiKey(result.api_key);

      process.stdout.write(
        [
          `✓ signed in as ${result.user.github_login}`,
          `  api key: ${result.prefix}… (stored in ${stored.storage})`,
          "",
        ].join("\n"),
      );
    });

  program
    .command("logout")
    .description("Remove the stored API key")
    .action(async () => {
      const { deleteApiKey, fallbackLocation } = await import("../keychain.js");
      const ok = await deleteApiKey();
      process.stdout.write(
        ok ? "✓ logged out\n" : `no key found (fallback path was ${fallbackLocation()})\n`,
      );
    });

  program
    .command("whoami")
    .description("Show the user behind the current API key")
    .option("--base-url <url>", "Override API base URL")
    .action(async (opts: { baseUrl?: string }) => {
      const { clientFromEnv } = await import("../client.js");
      const client = await clientFromEnv(opts.baseUrl);
      const result = await client.call<{
        user: { id: string; github_login: string | null; email: string | null };
      }>("/whoami");
      process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    });
}
