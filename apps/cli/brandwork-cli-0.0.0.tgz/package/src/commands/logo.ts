// `brandwork logo <domain>` — return real brand-accurate logos from multiple sources.
//
// Sources probed in parallel (5s timeout each):
//   1. Homepage scrape — <img src=*logo*>, <link rel="icon" type="image/svg+xml">
//   2. Wikipedia Commons API — "<brand> logo filetype:svg"
//   3. brandfetch.com API — free tier (requires BRANDFETCH_API_KEY)
//   4. logo.dev API — free tier (requires LOGO_DEV_TOKEN)
//   5. simpleicons.org — last resort, generic icons only
//
// All candidates with aspect_ratio 0.85–1.18 sourced from a favicon-shaped
// URL are moved to rejected[]. Real wordmarks are typically 2.5:1 to 5:1.

import type { Command } from "commander";
import { clientFromEnv } from "../client.js";
import { emit, progress, runAction, warn } from "../output.js";

// ── Types ────────────────────────────────────────────────────────────────────

export interface LogoCandidate {
  url: string;
  source: string;
  format: "svg" | "png" | "jpg" | "unknown";
  width?: number;
  height?: number;
  aspect_ratio?: number;
  confidence: number;
  rationale: string;
}

export interface RejectedCandidate {
  url: string;
  source: string;
  format: "svg" | "png" | "jpg" | "unknown";
  width?: number;
  height?: number;
  aspect_ratio?: number;
  rejection_reason: string;
}

export interface LogoResult {
  domain: string;
  candidates: LogoCandidate[];
  recommended: number;
  rejected: RejectedCandidate[];
}

// ── In-process fetch cache (keyed by URL) ────────────────────────────────────

const fetchCache = new Map<string, string | null>();

async function cachedFetch(
  url: string,
  opts?: RequestInit,
  timeoutMs = 5000,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function cachedFetchText(url: string, timeoutMs = 5000): Promise<string | null> {
  if (fetchCache.has(url)) return fetchCache.get(url) ?? null;
  try {
    const res = await cachedFetch(url, { headers: { "User-Agent": "brandwork-logo/1.0" } }, timeoutMs);
    if (!res.ok) {
      fetchCache.set(url, null);
      return null;
    }
    const text = await res.text();
    fetchCache.set(url, text);
    return text;
  } catch {
    fetchCache.set(url, null);
    return null;
  }
}

// ── Format detection ─────────────────────────────────────────────────────────

function detectFormat(url: string, contentType?: string | null): "svg" | "png" | "jpg" | "unknown" {
  const lower = url.toLowerCase();
  if (lower.includes(".svg") || contentType?.includes("svg")) return "svg";
  if (lower.includes(".png") || contentType?.includes("png")) return "png";
  if (lower.includes(".jpg") || lower.includes(".jpeg") || contentType?.includes("jpeg")) return "jpg";
  return "unknown";
}

// ── Favicon-path detection ───────────────────────────────────────────────────

const FAVICON_RE = /favicon|apple-touch|icon-\d/i;

function isFaviconUrl(url: string): boolean {
  return FAVICON_RE.test(url);
}

// ── Aspect ratio validation ──────────────────────────────────────────────────

/**
 * Returns true when the candidate looks like an app icon (square/near-square)
 * AND its URL matches favicon patterns. Both signals required to avoid
 * rejecting legitimate square logomarks.
 */
export function isAppIconCandidate(
  url: string,
  aspectRatio: number | undefined,
): boolean {
  if (aspectRatio == null) return false;
  return isFaviconUrl(url) && aspectRatio >= 0.85 && aspectRatio <= 1.18;
}

// ── Confidence scoring ───────────────────────────────────────────────────────

const SOURCE_TIER_PTS: Record<number, number> = {
  1: 0.40,
  2: 0.30,
  3: 0.20,
  4: 0.10,
  5: 0.05,
};

export function computeConfidence(opts: {
  sourceTier: 1 | 2 | 3 | 4 | 5;
  format: "svg" | "png" | "jpg" | "unknown";
  aspectRatio?: number;
  width?: number;
}): number {
  const sourcePts = SOURCE_TIER_PTS[opts.sourceTier] ?? 0;
  const formatPts =
    opts.format === "svg" ? 0.30 :
    opts.format === "png" ? 0.20 :
    opts.format === "jpg" ? 0.05 : 0.0;
  const aspectPts =
    opts.aspectRatio != null && opts.aspectRatio >= 2.5 && opts.aspectRatio <= 5.0 ? 0.20 : 0.0;
  const sizePts = opts.width != null && opts.width >= 200 ? 0.10 : 0.0;

  return Math.min(1.0, sourcePts + formatPts + aspectPts + sizePts);
}

// ── SVG dimension extraction ─────────────────────────────────────────────────

function parseSvgDimensions(svgText: string): { width?: number; height?: number } {
  const viewBoxMatch = svgText.match(/viewBox=["']([^"']+)["']/i);
  if (viewBoxMatch?.[1]) {
    const parts = viewBoxMatch[1].trim().split(/[\s,]+/);
    if (parts.length === 4) {
      const w = Number.parseFloat(parts[2] ?? "0");
      const h = Number.parseFloat(parts[3] ?? "0");
      if (w > 0 && h > 0) return { width: w, height: h };
    }
  }
  const wMatch = svgText.match(/\bwidth=["']([0-9.]+)/i);
  const hMatch = svgText.match(/\bheight=["']([0-9.]+)/i);
  const w = wMatch?.[1] ? Number.parseFloat(wMatch[1]) : undefined;
  const h = hMatch?.[1] ? Number.parseFloat(hMatch[1]) : undefined;
  if (w && h) return { width: w, height: h };
  return {};
}

// ── HTML parsing helpers ─────────────────────────────────────────────────────

const LOGO_SRC_RE = /logo|brand|wordmark/i;
const LOGO_ALT_RE = /logo|wordmark/i;

function resolveUrl(origin: string, src: string): string | null {
  try {
    return new URL(src, origin).toString();
  } catch {
    return null;
  }
}

/**
 * Parse logo candidates from raw HTML — exported for unit testing without
 * network calls.
 */
export function probeHomepageFromHtml(
  origin: string,
  html: string,
): Array<{ url: string; note: string }> {
  const results: Array<{ url: string; note: string }> = [];

  // <img src=...logo...> or alt contains logo/wordmark
  const imgTagRe = /<img[^>]+>/gi;
  let match: RegExpExecArray | null;
  while ((match = imgTagRe.exec(html)) !== null) {
    const tag = match[0];
    const srcMatch = tag.match(/src=["']([^"']+)["']/i);
    const altMatch = tag.match(/alt=["']([^"']*?)["']/i);
    if (!srcMatch?.[1]) continue;
    const src = srcMatch[1];
    const alt = altMatch?.[1] ?? "";
    if (LOGO_SRC_RE.test(src) || LOGO_ALT_RE.test(alt)) {
      const resolved = resolveUrl(origin, src);
      if (resolved) {
        results.push({ url: resolved, note: `homepage <img> (alt="${alt}")` });
      }
    }
  }

  // <link rel="icon" type="image/svg+xml">
  const linkRe = /<link[^>]+>/gi;
  while ((match = linkRe.exec(html)) !== null) {
    const tag = match[0];
    if (/rel=["'][^"']*icon[^"']*["']/i.test(tag) && /type=["'][^"']*svg[^"']*["']/i.test(tag)) {
      const hrefMatch = tag.match(/href=["']([^"']+)["']/i);
      if (hrefMatch?.[1]) {
        const resolved = resolveUrl(origin, hrefMatch[1]);
        if (resolved) results.push({ url: resolved, note: "homepage <link rel=icon type=svg>" });
      }
    }
  }

  return results;
}

// ── Source 1: Homepage scrape ────────────────────────────────────────────────

async function probeHomepage(domain: string): Promise<Array<{ url: string; note: string }>> {
  const origin = `https://${domain}`;
  const html = await cachedFetchText(origin);
  if (!html) return [];

  const results = probeHomepageFromHtml(origin, html);

  // manifest.json — look for wide-aspect icons (likely wordmarks)
  const manifestLinkRe = /<link[^>]+rel=["'][^"']*manifest[^"']*["'][^>]*>/i;
  const manifestMatch = html.match(manifestLinkRe);
  if (manifestMatch) {
    const hrefMatch = manifestMatch[0].match(/href=["']([^"']+)["']/i);
    if (hrefMatch?.[1]) {
      const manifestUrl = resolveUrl(origin, hrefMatch[1]);
      if (manifestUrl) {
        const manifestText = await cachedFetchText(manifestUrl);
        if (manifestText) {
          try {
            const manifest = JSON.parse(manifestText) as {
              icons?: Array<{ src: string; sizes?: string; type?: string }>;
            };
            for (const icon of manifest.icons ?? []) {
              if (!icon.src) continue;
              const sizes = icon.sizes ?? "";
              const [wStr, hStr] = sizes.split("x");
              const w = Number.parseInt(wStr ?? "0", 10);
              const h = Number.parseInt(hStr ?? "0", 10);
              if (w > 0 && h > 0 && w / h >= 2.5) {
                const resolved = resolveUrl(origin, icon.src);
                if (resolved) results.push({ url: resolved, note: "manifest.json wide icon" });
              }
            }
          } catch {
            // malformed manifest — skip
          }
        }
      }
    }
  }

  return results;
}

// ── Source 2: Wikipedia Commons ──────────────────────────────────────────────

interface WikiSearchResult {
  title: string;
  // biome-ignore lint/suspicious/noExplicitAny: API response
  [k: string]: any;
}

async function probeWikipediaCommons(brandName: string): Promise<Array<{ url: string; note: string }>> {
  const results: Array<{ url: string; note: string }> = [];
  const query = encodeURIComponent(`${brandName} logo`);
  const apiUrl =
    `https://commons.wikimedia.org/w/api.php?action=query&list=search` +
    `&srsearch=${query}+filetype:svg&srnamespace=6&srlimit=5&format=json&origin=*`;

  try {
    const res = await cachedFetch(apiUrl, { headers: { "User-Agent": "brandwork-logo/1.0" } }, 5000);
    if (!res.ok) return results;
    const data = await res.json() as {
      query?: { search?: WikiSearchResult[] };
    };
    const hits = data.query?.search ?? [];
    for (const hit of hits.slice(0, 3)) {
      const title = hit.title as string;
      if (!title.toLowerCase().includes(".svg")) continue;
      const infoUrl =
        `https://commons.wikimedia.org/w/api.php?action=query&titles=${encodeURIComponent(title)}` +
        `&prop=imageinfo&iiprop=url&format=json&origin=*`;
      try {
        const infoRes = await cachedFetch(infoUrl, { headers: { "User-Agent": "brandwork-logo/1.0" } }, 5000);
        if (!infoRes.ok) continue;
        const infoData = await infoRes.json() as {
          query?: { pages?: Record<string, { imageinfo?: Array<{ url: string }> }> };
        };
        const pages = infoData.query?.pages ?? {};
        for (const page of Object.values(pages)) {
          const imageUrl = page.imageinfo?.[0]?.url;
          if (imageUrl) {
            results.push({ url: imageUrl, note: `Wikipedia Commons (${title})` });
          }
        }
      } catch {
        // skip this hit
      }
    }
  } catch {
    // network error — skip
  }

  return results;
}

// ── Source 3: brandfetch.com API ─────────────────────────────────────────────

interface BrandfetchLogo {
  type?: string;
  formats?: Array<{ src: string; format: string; width?: number; height?: number }>;
}

async function probeBrandfetch(domain: string): Promise<Array<{ url: string; note: string; width?: number; height?: number }>> {
  const apiKey = process.env["BRANDFETCH_API_KEY"];
  if (!apiKey) return [];

  const results: Array<{ url: string; note: string; width?: number; height?: number }> = [];
  try {
    const res = await cachedFetch(
      `https://api.brandfetch.io/v2/brands/${domain}`,
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "User-Agent": "brandwork-logo/1.0",
        },
      },
      5000,
    );
    if (!res.ok) return results;
    const data = await res.json() as { logos?: BrandfetchLogo[] };
    for (const logo of data.logos ?? []) {
      if (logo.type !== "logo" && logo.type !== "symbol") continue;
      for (const fmt of logo.formats ?? []) {
        if (!fmt.src) continue;
        results.push({
          url: fmt.src,
          note: `brandfetch.com (${logo.type})`,
          width: fmt.width,
          height: fmt.height,
        });
      }
    }
  } catch {
    // skip
  }

  return results;
}

// ── Source 4: logo.dev API ───────────────────────────────────────────────────

async function probeLogoDev(domain: string): Promise<Array<{ url: string; note: string }>> {
  const token = process.env["LOGO_DEV_TOKEN"] ?? "pk_LnmkC1eSR0uHkM2A0QbPhQ";
  const url = `https://img.logo.dev/${domain}?token=${token}&format=svg`;
  const results: Array<{ url: string; note: string }> = [];

  try {
    const res = await cachedFetch(url, { method: "HEAD", headers: { "User-Agent": "brandwork-logo/1.0" } }, 5000);
    if (res.ok) {
      const ct = res.headers.get("content-type") ?? "";
      if (ct.includes("svg") || ct.includes("image")) {
        results.push({ url, note: "logo.dev API" });
      }
    }
  } catch {
    // skip
  }

  return results;
}

// ── Source 5: simpleicons.org ────────────────────────────────────────────────

async function probeSimpleIcons(brandName: string): Promise<Array<{ url: string; note: string }>> {
  const slug = brandName.toLowerCase().replace(/[^a-z0-9]/g, "");
  const url = `https://simpleicons.org/icons/${slug}.svg`;
  const results: Array<{ url: string; note: string }> = [];

  try {
    const res = await cachedFetch(url, { method: "HEAD", headers: { "User-Agent": "brandwork-logo/1.0" } }, 5000);
    if (res.ok) {
      results.push({ url, note: "simpleicons.org (generic icon — last resort)" });
    }
  } catch {
    // skip
  }

  return results;
}

// ── Brand name extraction from domain ───────────────────────────────────────

function brandNameFromDomain(domain: string): string {
  const sld = domain.replace(/^www\./, "").split(".")[0] ?? domain;
  return sld.charAt(0).toUpperCase() + sld.slice(1);
}

// ── Candidate validation ─────────────────────────────────────────────────────

interface ValidatedCandidate {
  url: string;
  format: "svg" | "png" | "jpg" | "unknown";
  contentType: string | null;
  contentLength: number | null;
  svgConfirmed: boolean;
}

async function validateCandidate(url: string): Promise<ValidatedCandidate | null> {
  try {
    const res = await cachedFetch(
      url,
      { method: "HEAD", headers: { "User-Agent": "brandwork-logo/1.0" } },
      5000,
    );
    if (!res.ok) return null;

    const contentType = res.headers.get("content-type");
    const contentLengthStr = res.headers.get("content-length");
    const contentLength = contentLengthStr ? Number.parseInt(contentLengthStr, 10) : null;
    const format = detectFormat(url, contentType);

    // PNG too small = likely tracker pixel
    if (format === "png" && contentLength != null && contentLength < 4000) return null;

    // SVG: confirm <svg is present in first 2KB
    let svgConfirmed = false;
    if (format === "svg" || contentType?.includes("svg")) {
      try {
        const rangeRes = await cachedFetch(
          url,
          {
            headers: {
              "User-Agent": "brandwork-logo/1.0",
              "Range": "bytes=0-2047",
            },
          },
          5000,
        );
        if (rangeRes.ok) {
          const snippet = await rangeRes.text();
          svgConfirmed = snippet.includes("<svg") || snippet.includes("<SVG");
        }
      } catch {
        // range not supported — treat as confirmed if content-type says svg
        svgConfirmed = contentType?.includes("svg") ?? false;
      }
    }

    return { url, format, contentType, contentLength, svgConfirmed };
  } catch {
    return null;
  }
}

// ── Main probe orchestration ─────────────────────────────────────────────────

async function gatherCandidates(domain: string): Promise<{
  raw: Array<{ url: string; source: string; tier: 1 | 2 | 3 | 4 | 5; width?: number; height?: number }>;
}> {
  const brandName = brandNameFromDomain(domain);

  const [homepageHits, wikiHits, brandfetchHits, logoDevHits, simpleIconsHits] =
    await Promise.allSettled([
      probeHomepage(domain),
      probeWikipediaCommons(brandName),
      probeBrandfetch(domain),
      probeLogoDev(domain),
      probeSimpleIcons(brandName),
    ]);

  const raw: Array<{ url: string; source: string; tier: 1 | 2 | 3 | 4 | 5; width?: number; height?: number }> = [];

  if (homepageHits.status === "fulfilled") {
    for (const h of homepageHits.value) {
      raw.push({ url: h.url, source: h.note, tier: 1 });
    }
  }
  if (wikiHits.status === "fulfilled") {
    for (const h of wikiHits.value) {
      raw.push({ url: h.url, source: h.note, tier: 2 });
    }
  }
  if (brandfetchHits.status === "fulfilled") {
    for (const h of brandfetchHits.value) {
      raw.push({ url: h.url, source: h.note, tier: 3, width: h.width, height: h.height });
    }
  }
  if (logoDevHits.status === "fulfilled") {
    for (const h of logoDevHits.value) {
      raw.push({ url: h.url, source: h.note, tier: 4 });
    }
  }
  if (simpleIconsHits.status === "fulfilled") {
    for (const h of simpleIconsHits.value) {
      raw.push({ url: h.url, source: h.note, tier: 5 });
    }
  }

  return { raw };
}

// ── Build LogoResult ─────────────────────────────────────────────────────────

function buildRationale(
  source: string,
  format: "svg" | "png" | "jpg" | "unknown",
  aspectRatio: number | undefined,
  width: number | undefined,
  svgConfirmed: boolean,
): string {
  const parts: string[] = [];
  parts.push(`source: ${source}`);
  if (format === "svg") {
    parts.push(svgConfirmed ? "confirmed SVG" : "SVG format");
  } else if (format === "png") {
    parts.push("PNG format");
  }
  if (aspectRatio != null) {
    if (aspectRatio >= 2.5 && aspectRatio <= 5.0) {
      parts.push(`wide aspect ratio ${aspectRatio.toFixed(1)} (likely wordmark)`);
    } else {
      parts.push(`aspect ratio ${aspectRatio.toFixed(1)}`);
    }
  }
  if (width != null && width >= 200) {
    parts.push(`width ${width}px`);
  }
  return parts.join("; ");
}

async function buildLogoResult(domain: string, skipSimpleIcons: boolean): Promise<LogoResult> {
  const { raw } = await gatherCandidates(domain);

  // Deduplicate by URL
  const seen = new Set<string>();
  const deduped = raw.filter((r) => {
    if (seen.has(r.url)) return false;
    seen.add(r.url);
    return true;
  });

  const candidates: LogoCandidate[] = [];
  const rejected: RejectedCandidate[] = [];

  const validations = await Promise.allSettled(
    deduped.map(async (r) => ({ raw: r, validated: await validateCandidate(r.url) })),
  );

  for (const v of validations) {
    if (v.status !== "fulfilled" || !v.value.validated) continue;
    const { raw: r, validated } = v.value;

    const format = validated.format;

    if (skipSimpleIcons && r.tier === 5) continue;

    let width = r.width;
    let height = r.height;

    if (format === "svg" && (!width || !height)) {
      const svgText = fetchCache.get(r.url);
      if (svgText) {
        const dims = parseSvgDimensions(svgText);
        width = dims.width ?? width;
        height = dims.height ?? height;
      }
    }

    const aspectRatio = width && height ? width / height : undefined;

    if (isAppIconCandidate(r.url, aspectRatio)) {
      rejected.push({
        url: r.url,
        source: r.source,
        format,
        width,
        height,
        aspect_ratio: aspectRatio,
        rejection_reason: "aspect_ratio_app_icon — square graphic, not a wordmark",
      });
      continue;
    }

    const confidence = computeConfidence({
      sourceTier: r.tier,
      format,
      aspectRatio,
      width,
    });

    const rationale = buildRationale(r.source, format, aspectRatio, width, validated.svgConfirmed);

    candidates.push({
      url: r.url,
      source: r.source,
      format,
      ...(width != null ? { width } : {}),
      ...(height != null ? { height } : {}),
      ...(aspectRatio != null ? { aspect_ratio: Math.round(aspectRatio * 100) / 100 } : {}),
      confidence: Math.round(confidence * 100) / 100,
      rationale,
    });
  }

  candidates.sort((a, b) => b.confidence - a.confidence);

  return {
    domain,
    candidates,
    recommended: candidates.length > 0 ? 0 : -1,
    rejected,
  };
}

// ── Human format ─────────────────────────────────────────────────────────────

function formatHuman(result: LogoResult): string {
  const lines: string[] = [`logo candidates for ${result.domain}`];
  if (result.candidates.length === 0) {
    lines.push("  no candidates found");
  } else {
    for (let i = 0; i < result.candidates.length; i++) {
      const c = result.candidates[i]!;
      const tag = i === result.recommended ? " [recommended]" : "";
      lines.push(`  ${i + 1}. [${c.confidence.toFixed(2)}] ${c.url}${tag}`);
      lines.push(`       source: ${c.source}, format: ${c.format}`);
      if (c.aspect_ratio != null) lines.push(`       aspect: ${c.aspect_ratio}`);
    }
  }
  if (result.rejected.length > 0) {
    lines.push(`  rejected (${result.rejected.length}):`);
    for (const r of result.rejected) {
      lines.push(`    - ${r.url}: ${r.rejection_reason}`);
    }
  }
  return lines.join("\n");
}

// ── API-assisted homepage fetch ───────────────────────────────────────────────
//
// When the direct homepage scrape yields no candidates (WAF block), we fall
// back to calling POST /scrape on the managed API.  The API routes through
// cf-browser → context-dev → firecrawl and returns rendered HTML.  We then
// run the same probeHomepageFromHtml logic against that HTML.

async function fetchHomepageViaApi(
  domain: string,
  baseUrl?: string,
): Promise<string | null> {
  try {
    const client = await clientFromEnv(baseUrl);
    const scrapeResult = await client.scrape.fetch(`https://${domain}`, { expect: "html" });
    if (scrapeResult.ok && scrapeResult.body) {
      return scrapeResult.body;
    }
  } catch {
    // API fallback failed — caller will handle empty result
  }
  return null;
}

// ── Command registration ─────────────────────────────────────────────────────

interface LogoOptions {
  skipSimpleIcons: boolean;
  baseUrl?: string;
}

export function registerLogo(program: Command): void {
  program
    .command("logo <domain>")
    .description(
      "Return real brand-accurate logos from multiple sources (homepage scrape, Wikipedia Commons, brandfetch.com, logo.dev). On WAF-block (403), falls back to the managed API (cf-browser → context-dev → firecrawl). Rejects favicons and app-icon-shaped candidates.",
    )
    .option("--skip-simple-icons", "Skip simpleicons.org even if no other SVG was found", false)
    .option("--base-url <url>", "Override API base URL (used for WAF-bypass fallback)")
    .action((domain: string, opts: LogoOptions) =>
      runAction(async () => {
        progress(`probing logo sources for ${domain}…`);

        const hasBetterSources = !!process.env["BRANDFETCH_API_KEY"] || !!process.env["LOGO_DEV_TOKEN"];
        const skipSimpleIcons = opts.skipSimpleIcons || hasBetterSources;

        let result = await buildLogoResult(domain, skipSimpleIcons);

        // If no candidates and homepage fetch likely WAF-blocked, try the managed
        // API which routes through cf-browser / context-dev / firecrawl.
        if (result.candidates.length === 0 && !fetchCache.get(`https://${domain}`)) {
          progress(`direct fetch blocked — retrying via managed API…`);
          const html = await fetchHomepageViaApi(domain, opts.baseUrl);
          if (html) {
            fetchCache.set(`https://${domain}`, html);
            // Re-run the full logo extraction now that we have the HTML.
            result = await buildLogoResult(domain, skipSimpleIcons);
          }
        }

        if (result.candidates.length === 0 && result.rejected.length > 0) {
          warn(`all ${result.rejected.length} candidate(s) rejected — try with a broader search`);
        }

        emit(result, formatHuman(result));
      }),
    );
}
